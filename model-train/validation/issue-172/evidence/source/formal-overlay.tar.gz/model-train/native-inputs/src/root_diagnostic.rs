//! 根时间资格唯一归属。公共生命周期状态不是模型资格，隐藏值由调用方持有。
use contracts::*;
use serde::Serialize;
use shared_run::{ActionBeforeReadV2, SharedExecutionV2};
use sim_system::{
    execution::PublicConsumptionStateV1, public_consumption::TrustedGroupDecisionCutoffV1,
};
use std::collections::{BTreeMap, BTreeSet};

use crate::root::{HiddenKey,HiddenOp,InputRole,AccountInputRow,NativeActionContext,NativeInputGroup,MarketBinding};
#[derive(Clone)]
pub struct NativeInputRoot {
    pub(crate) snapshot: std::sync::Arc<sim_system::platform_rules::SealedProcessRuleSnapshotV3>,
    pub(crate) trajectory: String,
    pub(crate) account: AccountInstanceKeyV1,
    pub(crate) started_at: i64,
    pub(crate) reset: bool,
    pub(crate) markets: BTreeMap<String, MarketBinding>,
    pub(crate) hidden: BTreeSet<String>,
    pub(crate) histories: BTreeMap<String, crate::market_diagnostic::MarketHistory>,
}
impl NativeInputRoot {
    pub fn new(
        trajectory_id: String,
        account_id: AccountInstanceKeyV1,
        root_started_at_utc_ms: i64,
        snapshot: std::sync::Arc<sim_system::platform_rules::SealedProcessRuleSnapshotV3>,
    ) -> Self {
        Self {
            snapshot,
            trajectory: trajectory_id,
            account: account_id,
            started_at: root_started_at_utc_ms,
            reset: false,
            markets: BTreeMap::new(),
            hidden: BTreeSet::new(),
            histories: BTreeMap::new(),
        }
    }
    fn key(&self, c: &str) -> HiddenKey {
        HiddenKey {
            trajectory_id: self.trajectory.clone(),
            account_id: self.account.clone(),
            condition_id: ConditionId(c.into()),
        }
    }
    pub fn consume(
        &mut self,
        shared: &mut SharedExecutionV2,
        driver: &mut PublicConsumptionStateV1,
    ) -> Result<Option<NativeInputGroup>, crate::InputError> {
        // 由原共享组合完成唯一应用；随后重取真实 decision 和公共帧。
        let account_start=std::time::Instant::now();let before=shared.action_before(driver)?;crate::diagnostic::elapsed("account_freeze",account_start);
        let Some(decision) = driver.decision() else {
            return Ok(None);
        };
        let cutoff = decision.cutoff().clone();
        let frames = decision.frames();
        if !frames.is_empty() && before.is_none() {
            return Ok(None);
        }
        let now = cutoff.decision_time().logical_time_utc_ms();
        for f in &frames {
            self.markets
                .entry(f.observation.market.condition_id.0.clone())
                .or_insert_with(|| MarketBinding {
                    market: f.observation.market.clone(),
                    assets: f
                        .observation
                        .assets
                        .iter()
                        .map(|a| a.asset.clone())
                        .collect(),
                });
        }
        let eligible = |m: &MarketBinding| {
            i128::from(self.started_at) <= i128::from(m.market.window.start_at_utc_ms) - 30_000
        };
        let current = self
            .markets
            .values()
            .find(|m| {
                eligible(m)
                    && m.market.window.start_at_utc_ms <= now
                    && now < m.market.window.end_at_utc_ms
            })
            .map(|m| m.market.condition_id.clone());
        // 完整账户投影包括仅本地预留的市场；经济成交表不是市场人口权威。
        let without_frame;
        let ledger = if let Some(read) = &before {
            read.ledger()
        } else {
            without_frame = shared
                .ledger()
                .projection_v2()
                .ok_or(crate::InputError::MissingAssociation)?;
            &without_frame
        };
        let old: Vec<_> = ledger
            .market_projections
            .iter()
            .filter_map(|m| {
                self.markets
                    .get(&m.condition_id.0)
                    .filter(|b| eligible(b) && b.market.window.end_at_utc_ms <= now)
                    .map(|_| m.condition_id.clone())
            })
            .collect();
        let mut pre = Vec::new();
        if !self.reset {
            pre.push(HiddenOp::ResetRootHidden {
                trajectory_id: self.trajectory.clone(),
                account_id: self.account.clone(),
            });
        }
        for (id, m) in &self.markets {
            if eligible(m)
                && i128::from(now) >= i128::from(m.market.window.start_at_utc_ms) - 30_000
                && now < m.market.window.end_at_utc_ms
                && !self.hidden.contains(id)
            {
                pre.push(HiddenOp::InitializeZero {
                    hidden_state_key: self.key(id),
                });
            }
        }
        let mut roles: Vec<_> = frames
            .iter()
            .filter_map(|f| {
                let m = &self.markets[&f.observation.market.condition_id.0];
                if !eligible(m) || now >= m.market.window.end_at_utc_ms {
                    return None;
                }
                if now >= m.market.window.start_at_utc_ms {
                    Some((InputRole::DecisionRequired, m.market.condition_id.clone()))
                } else if i128::from(now) >= i128::from(m.market.window.start_at_utc_ms) - 30_000 {
                    Some((InputRole::ContextOnly, m.market.condition_id.clone()))
                } else {
                    None
                }
            })
            .collect();
        roles.sort_by(|a, b| {
            (a.0 == InputRole::DecisionRequired, &a.1.0)
                .cmp(&(b.0 == InputRole::DecisionRequired, &b.1.0))
        });
        let mut rows = Vec::new();
        let mut cancel = Vec::new();
        let mut cancel_intents = Vec::new();
        if let Some(read) = &before
            && !roles.is_empty()
        {
            let account_start=std::time::Instant::now();let slow=crate::account::encode(read,current.as_ref(),&old,&self.markets,now)?;crate::diagnostic::elapsed("account_encode",account_start);
            if roles
                .iter()
                .any(|(role, _)| *role == InputRole::DecisionRequired)
            {
                let ExecutionReadValueV1::Known(objects) =
                    read.cancel_objects_in(current.as_ref(), &old)
                else {
                    return Err(crate::InputError::MissingAssociation);
                };
                cancel = crate::cancel::encode(
                    read,
                    &objects,
                    current.as_ref(),
                    &old,
                    &self.markets,
                    now,
                )?;
                cancel_intents = objects
                    .into_iter()
                    .map(crate::action::cancel_object_intent)
                    .collect();
            }
            for (role, id) in roles {
                let mut slow = slow;
                slow[if role == InputRole::DecisionRequired {
                    93
                } else {
                    94
                }] = 1.;
                let frame = frames
                    .iter()
                    .find(|f| f.observation.market.condition_id == id)
                    .unwrap();
                let rule = crate::market_diagnostic::rules(frame.observation, &frame.rule_context, now);
                rows.push(AccountInputRow {
                    hidden_state_key: self.key(&id.0),
                    role,
                    fast: Vec::new(),
                    book_levels: std::array::from_fn(|_| Vec::new()),
                    rule,
                    action_context: (role == InputRole::DecisionRequired).then(|| {
                        NativeActionContext::from_observation(
                            frame.observation,
                            frame.rule_context.clone(),
                            self.snapshot.clone(),
                        )
                    }),
                    slow: slow.to_vec(),
                });
            }
        }
        for row in &mut rows {
            let id = &row.hidden_state_key.condition_id;
            let frame = frames
                .iter()
                .find(|f| &f.observation.market.condition_id == id)
                .unwrap();
            let history=self.histories.entry(id.0.clone()).or_default();
            let (fast, book) = crate::bench_pool::get().install(|| crate::market_diagnostic::encode(
                frame.observation,
                &row.rule,
                now,
                history,
            ));
            row.fast = fast.to_vec();
            row.book_levels = book;
        }
        self.reset = true;
        for op in &pre {
            if let HiddenOp::InitializeZero { hidden_state_key } = op {
                self.hidden.insert(hidden_state_key.condition_id.0.clone());
            }
        }
        let retiring: Vec<_> = self
            .hidden
            .iter()
            .filter(|id| self.markets[*id].market.window.end_at_utc_ms <= now)
            .cloned()
            .collect();
        let mut post = Vec::new();
        for id in retiring {
            self.hidden.remove(&id);
            self.histories.remove(&id);
            post.push(HiddenOp::Retire {
                hidden_state_key: self.key(&id),
            });
        }
        Ok(Some(NativeInputGroup {
            cutoff,
            pre_frame_hidden_ops: pre,
            rows,
            post_frame_hidden_ops: post,
            current,
            old,
            cancel,
            action_before: before,
            cancel_intents,
        }))
    }
}

impl NativeInputRoot {pub fn from_baseline(r:&crate::root_baseline::NativeInputRoot)->Self {Self {snapshot:r.snapshot.clone(),trajectory:r.trajectory.clone(),account:r.account.clone(),started_at:r.started_at,reset:r.reset,markets:r.markets.clone(),hidden:r.hidden.clone(),histories:r.histories.iter().map(|(k,h)|(k.clone(),crate::market_diagnostic::MarketHistory::from_baseline(h))).collect()}}}

impl NativeInputRoot {pub fn assert_matches(&self,r:&crate::root_baseline::NativeInputRoot) {
        assert_eq!(self.trajectory,r.trajectory);assert_eq!(self.account,r.account);assert_eq!(self.started_at,r.started_at);
        assert!(std::sync::Arc::ptr_eq(&self.snapshot,&r.snapshot));
        assert_eq!(serde_json::to_value(self.markets.iter().map(|(k,v)|(k,(&v.market,&v.assets))).collect::<BTreeMap<_,_>>()).unwrap(),serde_json::to_value(r.markets.iter().map(|(k,v)|(k,(&v.market,&v.assets))).collect::<BTreeMap<_,_>>()).unwrap());
        assert_eq!(self.reset,r.reset);assert_eq!(self.hidden,r.hidden);assert_eq!(self.histories.len(),r.histories.len());
        for (k,h) in &self.histories {h.assert_matches(&r.histories[k]);}
    }}
