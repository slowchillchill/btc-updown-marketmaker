use std::sync::{OnceLock,atomic::{AtomicUsize,Ordering}};
static POOLS:OnceLock<Vec<rayon::ThreadPool>>=OnceLock::new();
static INDEX:AtomicUsize=AtomicUsize::new(2);
pub fn set(index:usize) { INDEX.store(index,Ordering::Relaxed); let _=get(); }
pub fn get()-> &'static rayon::ThreadPool { &POOLS.get_or_init(|| [1,4,8,16].into_iter().map(|n| rayon::ThreadPoolBuilder::new().num_threads(n).build().unwrap()).collect())[INDEX.load(Ordering::Relaxed)] }
