//! 从已有公共录制顺序消费完整原生输出，供有限真实连续验证和投影成本测量。
//! 模拟账户无交易；停止点是显式测量范围，不是生产丢帧或采样策略。
#[path="common/frame_runtime.rs"] mod frame_runtime;
use contracts::{execution_normalization::*, *};
use data_pipeline_core::public_input::*;
use data_pipeline_training::{canonical_run::CanonicalRunConfig, public_recording::*};
use ledger::{AccountAdmissionPolicyV2, LedgerWriterV1};
use model_native_inputs::{HiddenOp, InputRole, NativeInputRoot};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use shared_run::SharedExecutionV2;
use sim_system::{
    execution::*, finality::TradeFinalityPolicyV2,
    latency_profile::load_embedded_proxy_latency_profile, platform_rules::*, public_consumption::*,
    scenario::*,
};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs::{self, File},
    io::{BufWriter, Write},
    path::{Path, PathBuf},
    sync::Arc,
    time::Instant,
};

#[derive(Deserialize)]
struct Config {
    received_start: i64,
    condition: String,
    root_started_at: i64,
    canonical: CanonicalRunConfig,
    header: PublicInputStreamHeaderV1,
    rule_snapshot: PathBuf,
    rule_snapshot_sha256: Sha256Hex,
    finality_path: PathBuf,
    implementation_identity: ImplementationIdentityV1,
    initial_cash: String,
    max_group_bytes: usize,
    finite_in_flight_groups: usize,
}
fn json(path: impl AsRef<Path>, value: &impl Serialize) -> RecordingResult<()> {
    serde_json::to_writer_pretty(File::create(path)?, value)?;
    Ok(())
}
fn line(w: &mut impl Write, value: &impl Serialize) -> RecordingResult<()> {
    serde_json::to_writer(&mut *w, value)?;
    w.write_all(b"\n")?;
    Ok(())
}
fn sha(path: &Path) -> RecordingResult<Sha256Hex> {
    let mut f = File::open(path)?;
    let mut h = Sha256::new();
    std::io::copy(&mut f, &mut h)?;
    Ok(Sha256Hex(format!("{:x}", h.finalize())))
}
// 本次离线宿主单调交付：max(前组交付时刻,关闭输入原received)。原source时间/次序完全保留。
struct ReceivedTimes {
    reader: PublicRecordingReaderV1,
    current: Option<(u64, i64)>,
    last: i64,
    audit: std::rc::Rc<std::cell::RefCell<BufWriter<File>>>,
}
impl PublicConsumptionTimeSourceV1 for ReceivedTimes {
    fn execution_time_for_group(
        &mut self,
        group: &PublicGroupReferenceV1,
    ) -> Result<i64, SimRunActorErrorV2> {
        loop {
            if let Some((position, at)) = self.current
                && position == group.closed_at_input_position
            {
                // 离线测量宿主的显式交付规则；不冒称恢复了原生产策略时钟。
                let delivered = self.last.max(at);
                line(&mut *self.audit.borrow_mut(), &serde_json::json!({"group_position":group.group_position,"closed_at_input_position":position,"source_closing_received_at_utc_ms":at,"assigned_delivery_at_utc_ms":delivered,"delay_ms":delivered-at}))
                        .map_err(|e| SimRunActorErrorV2::PublicConsumptionSource(e.to_string()))?;
                self.last = delivered;
                return Ok(delivered);
            }
            let row = self
                .reader
                .next_row()
                .map_err(|e| SimRunActorErrorV2::PublicConsumptionSource(e.to_string()))?
                .ok_or_else(|| {
                    SimRunActorErrorV2::PublicConsumptionSource("组关闭输入未找到".into())
                })?;
            if let PublicStoredRowV1::Input(input) = row {
                match input.ingress {
                    DptIngressV1::Message {
                        source_evidence, ..
                    } => {
                        self.current =
                            Some((input.input_position, source_evidence.received_at_utc_ms))
                    }
                    DptIngressV1::EndOfInput => {
                        if let Some((_, at)) = self.current {
                            self.current = Some((input.input_position, at));
                        }
                    }
                    DptIngressV1::Aborted { .. } => {
                        return Err(SimRunActorErrorV2::PublicConsumptionSource(
                            "输入已中止".into(),
                        ));
                    }
                }
            }
        }
    }
}
fn retry<T, R>(
    state: &mut T,
    mut op: impl FnMut(&mut T) -> Result<R, SimRunActorErrorV2>,
    mut wait: impl FnMut(&mut T) -> Result<(), SimRunActorErrorV2>,
) -> Result<R, SimRunActorErrorV2> {
    loop {
        match op(state) {
            Err(SimRunActorErrorV2::RecordingBackpressured) => wait(state)?,
            result => return result,
        }
    }
}
fn trace(
    cfg: &Config,
    root: &Path,
    out: &Path,
    _stop_role: &str,
    _limit: u64,
) -> RecordingResult<()> {
    fs::create_dir(out)?;
    let rules = load_historical_process_snapshot_v3(HistoricalProcessSnapshotRequestV1 {
        snapshot_path: cfg.rule_snapshot.clone(),
        expected_file_sha256: cfg.rule_snapshot_sha256.clone(),
        replay_causal_start_utc_ms: cfg.received_start,
    })?;
    let finality = Arc::new(TradeFinalityPolicyV2::decode_and_seal(&fs::read(
        &cfg.finality_path,
    )?)?);
    let scenario = Arc::new(SealedPlatformScenarioV1::decode_and_seal(&fs::read(
        root.join("scenario.json"),
    )?)?);
    let latency = load_embedded_proxy_latency_profile()?;
    let run_id = cfg.header.input_stream_id.clone();
    let opened = RunOpenedV2 {
        projection_version: BusinessProjectionVersionV1::V4,
        run_id: run_id.clone(),
        durability_role: RunDurabilityRoleV2::CleanRun,
        platform_rule_snapshot_file_sha256: rules.file_sha256().clone(),
        trade_finality_policy_file_sha256: finality.policy_id().clone(),
        platform_scenario_file_sha256: scenario.file_sha256().clone(),
        proxy_latency_profile_file_sha256: latency.file_sha256().clone(),
        implementation_identity: cfg.implementation_identity.clone(),
        market_event_source_identity_sha256: Some(sha(&root.join("record-completion.json"))?),
    };
    let log = out.join("sim.jsonl");
    let reference = |position| DurableSourceReferenceV1 {
        source: ImmutableSourceReferenceV1::Location(format!("{}#input={position}", log.display())),
    };
    let port = MemoryNoeProjectionPortV4::new(
        out.join("noe"),
        opened.clone(),
        reference(0),
        reference(1),
        "create".into(),
        "realmarket-state-benchmark-no-trading".into(),
    );
    let observation = port.observation();
    let mut execution = PublicSimExecutionV1::create_new(
        &log,
        PublicRunOpenedV1 {
            projection_version: opened.projection_version,
            run_id: opened.run_id,
            platform_rule_snapshot_file_sha256: opened.platform_rule_snapshot_file_sha256,
            trade_finality_policy_file_sha256: opened.trade_finality_policy_file_sha256,
            platform_scenario_file_sha256: opened.platform_scenario_file_sha256,
            proxy_latency_profile_file_sha256: opened.proxy_latency_profile_file_sha256,
            implementation_identity: opened.implementation_identity,
            market_event_source_identity_sha256: opened.market_event_source_identity_sha256,
        },
        rules.clone(),
        finality,
        scenario,
        latency,
        Box::new(port),
        cfg.max_group_bytes,
        cfg.finite_in_flight_groups,
    )?;
    let session = SessionSpecV3 {
        run_id: run_id.clone(),
        session_id: "benchmark-session".into(),
        account_id: "benchmark-sim-account".into(),
        caller_role: SimCallerRoleV1::Paper,
        caller_instance_id: "benchmark-caller".into(),
        creation_request_id: "create".into(),
        response_bridge_binding_id: "benchmark-bridge".into(),
        initial_account_state: InitialAccountStateV2 {
            available_pusd: ExactDecimal(cfg.initial_cash.clone()),
        },
        session_seed: Sha256Hex(format!("{:x}", Sha256::digest(run_id.as_bytes()))),
    };
    retry(
        &mut execution,
        |e| e.create_session(session.clone()),
        PublicSimExecutionV1::wait_for_recording_capacity,
    )?;
    let mut ledger =
        LedgerWriterV1::new_with_admission_v2(AccountAdmissionPolicyV2::DualCashNoMarketLimit);
    execution.bind_ledger_recording_v2(&mut ledger, &out.join("ledger"))?;
    let mut shared = SharedExecutionV2::from_opening(ledger, observation)?.ok_or("缺少开户事实")?;
    retry(
        &mut execution,
        |e| e.activate_session("activate".into()),
        PublicSimExecutionV1::wait_for_recording_capacity,
    )?;
    let account = shared
        .ledger()
        .projection_v2()
        .ok_or("无账户投影")?
        .account_instance_key;
    let mut native = NativeInputRoot::new(run_id, account, cfg.root_started_at, rules);
    let rec = root.join("recording");
    let time_audit = std::rc::Rc::new(std::cell::RefCell::new(BufWriter::new(File::create(
        out.join("host-time-assignment.jsonl"),
    )?)));
    let times = ReceivedTimes {
        reader: PublicRecordingReaderV1::recover(
            &rec,
            cfg.canonical.decode_batch_rows,
            cfg.canonical.max_decode_batch_bytes,
        )?,
        current: None,
        last: i64::MIN,
        audit: time_audit.clone(),
    };
    let source = RecordedPublicGroupSourceV1::open(
        &rec,
        cfg.canonical.decode_batch_rows,
        cfg.canonical.max_decode_batch_bytes,
        times,
    )?;
    let mut driver = FinitePublicConsumptionV1::new(
        execution,
        source,
        "offline-host-monotone-closing-received-high-watermark-v1".into(),
    );
    let variant = "baseline";
    assert_eq!(std::env::var("FRAME_MODE").unwrap(), variant);
    let first: u64 = std::env::var("FRAME_FIRST").unwrap().parse().unwrap();
    let model = std::env::var("FRAME_MODEL").unwrap();
    let threads = if model == "MAIN-1x256" { 4 } else { 16 };
    let graphs = PathBuf::from(std::env::var("FRAME_GRAPHS").unwrap());
    let mut runtime = frame_runtime::Runtime::new(&graphs.join(&model), threads);
    let executor = tokio::runtime::Builder::new_current_thread().build().unwrap();
    let checkpoint = PathBuf::from(std::env::var("FRAME_CHECKPOINTS").unwrap()).join(format!("entry-{first}.json"));
    let mut measurements = BufWriter::new(File::create(out.join("measurements.jsonl"))?);
    let start = Instant::now();
    let preparation_cpu = process_cpu_ns();
    let mut count = 0;
    let mut service_total = 0u128;
    let mut evidence_total = 0u128;
    loop {
        let next = retry(&mut driver, FinitePublicConsumptionV1::next_group, FinitePublicConsumptionV1::wait_for_recording_capacity)?;
        let Some((_, cutoff)) = next else {break;};
        let position = cutoff.receipt().group().group_position;
        if position > first + 63 {break;}
        if position < first {shared.action_before(&mut driver)?;continue;}
        if position == first {
            let loaded: serde_json::Value = serde_json::from_slice(&fs::read(&checkpoint)?)?;
            assert_eq!(loaded["position"], position);
            assert_eq!(loaded["ledger"], serde_json::to_value(shared.ledger().projection_v2())?);
            native.restore_checkpoint(&loaded["native"]);
            runtime.restore(&loaded["runtimes"][if model == "MAIN-1x256" {0} else {1}]);
            line(&mut measurements, &serde_json::json!({"preparation_seconds":start.elapsed().as_secs_f64(),"preparation_cpu_ns":process_cpu_ns()-preparation_cpu,
                "graph_load_seconds":runtime.load_seconds,"graph_warmup_seconds":runtime.warmup_seconds,"entry_position":position,
                "restored_prior_model_rows":runtime.frames,"new_input_cache":"empty; first consume timed","ledger_equal":true,"native_threads":8,"ort_threads":threads}))?;
        }
        let cpu_before = process_cpu_ns();
        let began = Instant::now();
        let group = Arc::new(native.consume(&mut shared, &mut driver).map_err(|e|format!("consume: {e:?}"))?.unwrap());
        let native_ns = began.elapsed().as_nanos();
        let (actors, timing, states) = runtime.advance(group.clone(), true);
        let mut actions = Vec::new();
        for actor in actors {
            let at = Instant::now();
            driver.wait_for_recording_capacity()?;
            let receipt = executor.block_on(actor.execute(&mut shared, &mut driver.decision().unwrap(), RequestContextV2 {
                global_request_id:format!("model-{position}"),caller_correlation_id:None,
            })).map_err(|e|format!("execute: {e:?}"))?;
            actions.push((actor,receipt,at.elapsed().as_nanos()));
        }
        let service_ns = began.elapsed().as_nanos();
        let cpu_ns = process_cpu_ns() - cpu_before;
        service_total += service_ns;
        let evidence = Instant::now();
        let actions=actions.into_iter().map(|(actor,receipt,execute_ns)|serde_json::json!({"path":actor.path,"intent":format!("{:?}",actor.intent().unwrap()),"receipt":format!("{receipt:?}"),"execute_ns":execute_ns})).collect::<Vec<_>>();
        line(&mut measurements,&serde_json::json!({"position":position,"now":cutoff.decision_time().logical_time_utc_ms(),"service_ns":service_ns,"native_ns":native_ns,"cpu_ns":cpu_ns,
            "native_group":&*group,"native_bits_sha256":format!("{:x}",Sha256::digest(group.bench_f32_bits().iter().flat_map(|b|b.to_le_bytes()).collect::<Vec<_>>())),
            "native_business":native.bench_business(),"cache":native.bench_cache(),"ledger":shared.ledger().projection_v2(),
            "runtimes":[{"timing":timing,"hidden_sha256":runtime.hidden_digest(),"z_bits_sha256":format!("{:x}",Sha256::digest(states.iter().flatten().flat_map(|v|v.to_bits().to_le_bytes()).collect::<Vec<_>>())),"actions":actions}]}))?;
        count += 1;
        evidence_total += evidence.elapsed().as_nanos();
    }
    measurements.flush()?;
    time_audit.borrow_mut().flush()?;
    let loop_elapsed = start.elapsed().as_secs_f64();
    let drain = Instant::now();
    driver.stop_and_drain()?;
    assert_eq!(count,64);
    json(out.join("completion.json"), &serde_json::json!({"complete":true,"bounded_only":true,"variant":variant,"model":model,"groups":count,
        "actual_runtime_frames":runtime.frames,"loop_elapsed_seconds":loop_elapsed,"drain_seconds":drain.elapsed().as_secs_f64(),
        "elapsed_seconds":start.elapsed().as_secs_f64(),"service_total_ns":service_total,"evidence_total_ns":evidence_total}))?;
    Ok(())
}


fn main() -> RecordingResult<()> {
    let args: Vec<_> = std::env::args().collect();
    if args.len() != 6 {
        return Err("参数：配置JSON 公共录制根 输出目录 contexts|decisions 行数".into());
    }
    let cfg = serde_json::from_reader(File::open(&args[1])?)?;
    trace(
        &cfg,
        Path::new(&args[2]),
        Path::new(&args[3]),
        &args[4],
        args[5].parse()?,
    )
}

fn process_cpu_ns()->u128 {let mut v=libc::timespec{tv_sec:0,tv_nsec:0};assert_eq!(unsafe{libc::clock_gettime(libc::CLOCK_PROCESS_CPUTIME_ID,&mut v)},0);v.tv_sec as u128*1_000_000_000+v.tv_nsec as u128}
